class Contact {
	long id
	String firstName
	String lastName
	String phoneNumber
	String emailAddress
}