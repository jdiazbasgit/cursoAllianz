create table Things (
  id identity,
  name varchar(100)
);